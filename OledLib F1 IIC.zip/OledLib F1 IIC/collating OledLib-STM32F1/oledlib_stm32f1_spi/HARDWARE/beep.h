#ifndef __BEEP_H
#define __BEEP_H

#include "sys.h"

#define BEEP_CLK	RCC_APB2Periph_GPIOB
#define BEEP_PORT	GPIOB
#define BEEP_PIN	GPIO_Pin_5
#define LED_PIN	GPIO_Pin_6

#define BEEP	PBout(5)
#define LED	    PBout(6)

void BEEP_Init(void);

#endif

