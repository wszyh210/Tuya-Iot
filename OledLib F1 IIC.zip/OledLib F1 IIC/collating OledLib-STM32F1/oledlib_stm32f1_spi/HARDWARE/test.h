#ifndef TEST_H
#define TEST_H

void demo(void);
void ShowStars(void);
void ShowWatch(void);
void ShowPolygon(void);
void ShowSnow(void);


#endif

